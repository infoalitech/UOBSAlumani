<?php
$title = 'UOBS Alumni';
include 'snippets/header.php';
?>
    <section id="hero" class="hero section">
      <div class="container" data-aos="fade-up" data-aos-delay="100">

        <div class="row align-items-center">
          <div class="col-lg-6">
            <div class="hero-content" data-aos="fade-up" data-aos-delay="200">
              <div class="company-badge mb-4">
                <i class="bi bi-gear-fill me-2"></i>
                Working for your success
              </div>

              <h1 class="mb-4">
                Maecenas Vitae <br>
                Consectetur Led <br>
                <span class="accent-text">Vestibulum Ante</span>
              </h1>

              <p class="mb-4 mb-md-5">
                Nullam quis ante. Etiam sit amet orci eget eros faucibus tincidunt.
                Duis leo. Sed fringilla mauris sit amet nibh. Donec sodales sagittis magna.
              </p>

              <div class="hero-buttons">
                <a href="#about" class="btn btn-primary me-0 me-sm-2 mx-1">Get Started</a>
                <a href="https://www.youtube.com/watch?v=Y7f98aduVJ8" class="btn btn-link mt-2 mt-sm-0 glightbox">
                  <i class="bi bi-play-circle me-1"></i>
                  Play Video
                </a>
              </div>
            </div>
          </div>

          <div class="col-lg-6">
            <div class="hero-image" data-aos="zoom-out" data-aos-delay="300">
              <img src="assets/img/illustration-1.webp" alt="Hero Image" class="img-fluid">

              <div class="customers-badge">
                <div class="customer-avatars">
                  <img src="assets/img/avatar-1.webp" alt="Customer 1" class="avatar">
                  <img src="assets/img/avatar-2.webp" alt="Customer 2" class="avatar">
                  <img src="assets/img/avatar-3.webp" alt="Customer 3" class="avatar">
                  <img src="assets/img/avatar-4.webp" alt="Customer 4" class="avatar">
                  <img src="assets/img/avatar-5.webp" alt="Customer 5" class="avatar">
                  <span class="avatar more">12+</span>
                </div>
                <p class="mb-0 mt-2">12,000+ lorem ipsum dolor sit amet consectetur adipiscing elit</p>
              </div>
            </div>
          </div>
        </div>

        <div class="row stats-row gy-4 mt-5" data-aos="fade-up" data-aos-delay="500">
          <div class="col-lg-3 col-md-6">
            <div class="stat-item">
              <div class="stat-icon">
                <i class="bi bi-trophy"></i>
              </div>
              <div class="stat-content">
                <h4>3x Won Awards</h4>
                <p class="mb-0">Vestibulum ante ipsum</p>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6">
            <div class="stat-item">
              <div class="stat-icon">
                <i class="bi bi-briefcase"></i>
              </div>
              <div class="stat-content">
                <h4>6.5k Faucibus</h4>
                <p class="mb-0">Nullam quis ante</p>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6">
            <div class="stat-item">
              <div class="stat-icon">
                <i class="bi bi-graph-up"></i>
              </div>
              <div class="stat-content">
                <h4>80k Mauris</h4>
                <p class="mb-0">Etiam sit amet orci</p>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6">
            <div class="stat-item">
              <div class="stat-icon">
                <i class="bi bi-award"></i>
              </div>
              <div class="stat-content">
                <h4>6x Phasellus</h4>
                <p class="mb-0">Vestibulum ante ipsum</p>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section><!-- /Hero Section -->



    <!-- Service Details -->
    <!--  -->
<div class="container mt-4">
    <!-- Cover Image -->
    <div class="jumbotron text-center text-white p-5 rounded" style="background: url('https://uobs.edu.pk/images/main/sarfaranga.jpg') no-repeat center center; background-size: cover;">
        <h1>Welcome to UOBS Alumni Portal</h1>
        <p>Stay connected with fellow alumni, explore job opportunities, and read the latest blogs and news.</p>
    </div>
    
    <div class="row mt-4">
        <!-- Main Content -->
        <div class="col-lg-8">
            <!-- Latest Blogs -->
            <h2 class="mt-3">Latest Blogs</h2>
            <div class="row">
                <?php foreach ($latestBlogs as $blog): ?>
                    <div class="col-md-6">
                        <div class="card mb-3">
                            <img src="<?= $basePath ?>/<?= $blog['cover'] ?>" class="card-img-top" alt="<?= htmlspecialchars($blog['title']) ?>">
                            <div class="card-body">
                                <h5 class="card-title"><?= htmlspecialchars($blog['title']) ?></h5>
                                <a href="blog\detail?id=<?= $blog['id'] ?>" class="btn btn-primary">Read More</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Job Categories -->
            <h2 class="mt-5">Job Categories</h2>
            <div class="row">
                <?php foreach ($jobCategories as $category): ?>
                    <div class="col-md-4">
                        <div class="card mb-3">
                            <div class="card-body">
                                <h5 class="card-title"><?= htmlspecialchars($category['name']) ?></h5>
                                <a href="jobs.php?category=<?= $category['id'] ?>" class="btn btn-info">View Jobs</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="col-lg-4">
            <!-- Latest Job Posts -->
            <h3 class="mt-3">Latest Jobs</h3>
            <ul class="list-group">
                <?php foreach ($latestJobs as $job): ?>
                    <li class="list-group-item">
                        <strong><?= htmlspecialchars($job['title']) ?></strong><br>
                        <small><?= htmlspecialchars($job['company']) ?> - <?= htmlspecialchars($job['location']) ?></small><br>
                        <a href="jobDetail.php?id=<?= $job['id'] ?>" class="btn btn-sm btn-success mt-2">View Details</a>
                    </li>
                <?php endforeach; ?>
            </ul>
            
            <!-- Latest News -->
            <h3 class="mt-4">Latest News</h3>
            <ul class="list-group">
                <?php foreach ($latestNews as $news): ?>
                    <li class="list-group-item">
                        <strong><?= htmlspecialchars($news['title']) ?></strong><br>
                        <a href="newsDetail.php?id=<?= $news['id'] ?>" class="btn btn-sm btn-warning mt-2">Read More</a>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</div>

<?php include 'snippets/footer.php'; ?>
